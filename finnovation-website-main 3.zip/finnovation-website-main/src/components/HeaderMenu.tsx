import React, { useState } from "react";
import { Link } from "react-router-dom";

const HeaderMenu: React.FC = () => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);

  const toggleMenu = (menu: string) => {
    setActiveMenu((prev) => (prev === menu ? null : menu));
  };

  const texts = {
    tr: {
      home: "Biz Kimiz",
      expertise: "Uzmanlık Alanlarımız",
      academy: "FinAcademy",
      projects: "Projeler",
      career: "Kariyer",
      contact: "Bize Ulaşın",
      homeSubmenu: ["Hakkımızda", "Değerlerimiz", "Sürdürülebilirlik"],
      expertiseSubmenu: [
        "Danışmanlık",
        "Süreç İzleme ve Geliştirme",
        "Proje Bazlı Teknoloji ve Sistem Entegrasyonu",
        "Sürdürülebilirlik",
      ],
      projectsSubmenu: [
        "Temel Bankacılık",
        "Veri Yönetimi",
        "Dijital Dönüşüm",
        "Eğitim Danışmanlığı",
      ],
      careerSubmenu: ["Hazine", "Nakit Yönetimi", "Krediler", "Risk Yönetimi"],
    },
    en: {
      home: "About Us",
      expertise: "Our Expertise",
      academy: "FinAcademy",
      projects: "Projects",
      career: "Career",
      contact: "Contact Us",
      homeSubmenu: ["About Us", "Our Values", "Sustainability"],
      expertiseSubmenu: [
        "Consultancy",
        "Process Monitoring and Development",
        "Project-Based Technology and System Integration",
        "Sustainability",
      ],
      projectsSubmenu: [
        "Core Banking",
        "Data Management",
        "Digital Transformation",
        "Education Consultancy",
      ],
      careerSubmenu: ["Treasury", "Cash Management", "Credits", "Risk Management"],
    },
  };

  const [language, setLanguage] = useState<"tr" | "en">("tr");
  const t = texts[language];

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "tr" ? "en" : "tr"));
  };

  return (
      <header className="bg-gradient-to-r from-blue-500 to-teal-500 text-white p-4 relative">
        <nav className="flex justify-between items-center">
          {/* Sol Taraf */}
          <div className="flex items-center space-x-2">
            <img src="/img.png" alt="Finnovation Logo" className="h-8 w-auto" />
          </div>

          {/* Orta Menü */}
          <ul className="flex space-x-6 text-sm font-medium">
            <li
                onMouseEnter={() => toggleMenu("home")}
                onMouseLeave={() => toggleMenu(null)}
                className="relative"
            >
              <span className="hover:underline cursor-pointer">{t.home}</span>
              {activeMenu === "home" && (
                  <ul className="absolute bg-white text-blue-600 rounded shadow p-2 space-y-1">
                    {t.homeSubmenu.map((item, index) => (
                        <li key={index} className="hover:bg-gray-100 px-4 py-2 cursor-pointer">
                          {item}
                        </li>
                    ))}
                  </ul>
              )}
            </li>
            <li>
              <span className="text-gray-300">|</span>
            </li>
            <li
                onMouseEnter={() => toggleMenu("expertise")}
                onMouseLeave={() => toggleMenu(null)}
                className="relative"
            >
              <span className="hover:underline cursor-pointer">{t.expertise}</span>
              {activeMenu === "expertise" && (
                  <ul className="absolute bg-white text-blue-600 rounded shadow p-2 space-y-1">
                    {t.expertiseSubmenu.map((item, index) => (
                        <li key={index} className="hover:bg-gray-100 px-4 py-2 cursor-pointer">
                          {item}
                        </li>
                    ))}
                  </ul>
              )}
            </li>
            <li>
              <span className="text-gray-300">|</span>
            </li>
            <li>
              <Link to="/finacademy" className="hover:underline">
                {t.academy}
              </Link>
            </li>
            <li>
              <span className="text-gray-300">|</span>
            </li>
            <li
                onMouseEnter={() => toggleMenu("projects")}
                onMouseLeave={() => toggleMenu(null)}
                className="relative"
            >
              <span className="hover:underline cursor-pointer">{t.projects}</span>
              {activeMenu === "projects" && (
                  <ul className="absolute bg-white text-blue-600 rounded shadow p-2 space-y-1">
                    {t.projectsSubmenu.map((item, index) => (
                        <li key={index} className="hover:bg-gray-100 px-4 py-2 cursor-pointer">
                          {item}
                        </li>
                    ))}
                  </ul>
              )}
            </li>
            <li>
              <span className="text-gray-300">|</span>
            </li>
            <li
                onMouseEnter={() => toggleMenu("career")}
                onMouseLeave={() => toggleMenu(null)}
                className="relative"
            >
              <span className="hover:underline cursor-pointer">{t.career}</span>
              {activeMenu === "career" && (
                  <ul className="absolute bg-white text-blue-600 rounded shadow p-2 space-y-1">
                    {t.careerSubmenu.map((item, index) => (
                        <li key={index} className="hover:bg-gray-100 px-4 py-2 cursor-pointer">
                          {item}
                        </li>
                    ))}
                  </ul>
              )}
            </li>
            <li>
              <span className="text-gray-300">|</span>
            </li>
            <li>
              <Link to="/bize-ulasin" className="hover:underline">
                {t.contact}
              </Link>
            </li>
          </ul>

          {/* Sağ Dil Seçimi */}
          <div
              className="flex items-center bg-white px-3 py-1 rounded-full shadow space-x-3 cursor-pointer"
              onClick={toggleLanguage}
          >
          <span role="img" aria-label="Globe" className="text-blue-600">
            🌐
          </span>
            <span className="text-gray-300">|</span>
            <span role="img" aria-label={language === "tr" ? "Türkçe" : "İngilizce"} className="text-red-600">
            {language === "tr" ? "🇹🇷" : "🇺🇸"}
          </span>
          </div>
        </nav>
      </header>
  );
};

export default HeaderMenu;
